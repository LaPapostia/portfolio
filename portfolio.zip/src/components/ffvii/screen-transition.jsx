export function ScreenTransition({ show }) {
  if (!show) return null

  return <div className="ff7-screen-transition" />
}
